# ModelCenter Documentation

To build this doc locally, first

```
pip install -r docs/requirements.txt
```

then,

```
cd docs
make html
```

Then open the generated `docs/build/html/index.html` in your local browser. 